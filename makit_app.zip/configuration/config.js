module.exports={
    "facebook_api_key"      :     "2948119172088769",
    "facebook_api_secret"   :     "d06281f2aeeccd54edce359687270d5f",
    "callback_url"          :     "http://localhost:3000/auth/facebook/callback",
    "use_database"          :      true,
    "host"                  :     "localhost",
    "username"              :     "root",
    "password"              :     "",
    "database"              :     "Database Name"
  }