module.exports = function(){
this.getobj = function(obj){ return document.getElementById(`${obj}`)};
} 